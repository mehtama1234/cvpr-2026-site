CVPR repo harness Colab Pro+ handoff package. Start with REPO_HARNESS_COLAB_RUNBOOK.md.
