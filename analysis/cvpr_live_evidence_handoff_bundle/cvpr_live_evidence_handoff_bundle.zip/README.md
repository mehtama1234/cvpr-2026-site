CVPR live evidence handoff bundle. Start with LIVE_EVIDENCE_HANDOFF_RUNBOOK.md.
