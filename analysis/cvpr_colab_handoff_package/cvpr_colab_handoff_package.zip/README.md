# CVPR Colab Pro+ Handoff Package

Open `notebooks/cvpr_gpu_worker.ipynb` in Google Colab Pro+, run all ten job sections, run the final live export contract cell, download `cvpr_gpu_results.json`, place it at `source-code/learning/cvpr-colab-gpu-worker/_incoming/cvpr_gpu_results_live.json`, then run the intake and promotion commands from the runbook.
