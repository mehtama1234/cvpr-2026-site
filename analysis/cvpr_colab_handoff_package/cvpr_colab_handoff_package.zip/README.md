# CVPR Colab Pro+ Handoff Package

Open `notebooks/cvpr_gpu_worker.ipynb` in Google Colab Pro+, run the GPU notebook and any linked live worker lanes required by the promoted manifest, download `cvpr_gpu_results.json`, place it at `source-code/learning/cvpr-colab-gpu-worker/_incoming/cvpr_gpu_results_live.json`, then run the intake and promotion commands from the runbook.
